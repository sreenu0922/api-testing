function fn() {
  var env = karate.env; // get system property 'karate.env'
  var catalogAdminUser = karate.properties['catalogAdminUser'] || 'rahmat.ramadhani@happyfresh.com'
  karate.log('karate.env system property was:', env);
  if (!env) {
      env = 'staging';
    }
  var config = {
    env: env,
	myVarName: 'someValue',
	EnvStage: 'https://stage-api.happyfresh.com/api',
	Localhost: 'https://localhost',
	IntegrationTestEnv: 'http://localhost:8080',
	SearchStaging: 'https://search-v3-staging-ecs.happyfresh.net/api',
    basicAuth: 'Basic aXJraGFtLmhhcHB5ZnJlc2hAZ21haWwuY29tOklya2hhbWdhbnRlbmc=',
    token: '80fb432c56c14faa29e267ccee89df7c2dda70cee4521691',
    EnvFulfillmentStage: 'https://happyfresh.fsrv-gw-stage.happyfresh.net/api',
    FulfillmentTokenStage: '76d6qGkKE84X89Kn62U71D1YDyerd8oJ',
    SNDstockLocationID : '140',
    SNDlat : '-6.253253',
    SNDlon : '106.801583',
    SNDVersion: '3.44',
    SNDBuild: '293',
    StormSheetDB: 'https://sheetdb.io/api/v1/i4fbp9lb0dwxl',
    CatalogAdminUser: catalogAdminUser,
    KintounPublicStage: 'https://kintoun-stage.happyfresh.net',
    HfcAdminStage: 'https://hfc-api-stage.happyfresh.net',
    XrayCloudUrl: 'https://xray.cloud.getxray.app/api/v2',
    StratoPublicStage: 'https://strato-stage.happyfresh.net',
    WMSStage: 'https://wms-service-stage.happyfresh.net/ws',
    jdaUserId: java.lang.System.getenv('JDA_USER_ID'),
    jdaPassword: java.lang.System.getenv('JDA_PASSWORD'),
    dbUrlIntegrationTest: java.lang.System.getenv('INTEGRATION_TEST_DB_URL'),
    dbUsernameIntegrationTest: java.lang.System.getenv('INTEGRATION_TEST_DB_USERNAME'),
    dbPasswordIntegrationTest: java.lang.System.getenv('INTEGRATION_TEST_DB_PASSWORD'),
    dbNameIntegrationTestKintoun: java.lang.System.getenv('INTEGRATION_TEST_DB_NAME_KINTOUN'),
    dbNameIntegrationTestStrato: java.lang.System.getenv('INTEGRATION_TEST_DB_NAME_STRATO'),
    fulfillmentDbUrlStage: java.lang.System.getenv('FULFILLMENT_DB_URL'),
    fulfillmentDbNameStage: java.lang.System.getenv('FULFILLMENT_DB_NAME'),
    fulfillmentDbUsernameStage: java.lang.System.getenv('FULFILLMENT_DB_USERNAME'),
    fulfillmentDbPasswordStage: java.lang.System.getenv('FULFILLMENT_DB_PASSWORD'),
    alohaDbUrlStage: java.lang.System.getenv('ALOHA_DB_URL'),
    alohaDbNameStage: java.lang.System.getenv('ALOHA_DB_NAME'),
    alohaDbUsernameStage: java.lang.System.getenv('ALOHA_DB_USERNAME'),
    alohaDbPasswordStage: java.lang.System.getenv('ALOHA_DB_PASSWORD'),
    stratoDBUrl: java.lang.System.getenv('STRATO_DB_URL'),
    stratoDBName: java.lang.System.getenv('STRATO_DB_NAME'),
    stratoDBUsername: java.lang.System.getenv('STRATO_DB_USERNAME'),
    stratoDBPassword: java.lang.System.getenv('STRATO_DB_PASSWORD'),
    kintounDBUrl: java.lang.System.getenv('KINTOUN_DB_URL'),
    kintounDBName: java.lang.System.getenv('KINTOUN_DB_NAME'),
    kintounDBUsername: java.lang.System.getenv('KINTOUN_DB_USERNAME'),
    kintounDBPassword: java.lang.System.getenv('KINTOUN_DB_PASSWORD'),
    spreeDBUrl: java.lang.System.getenv('SPREE_DB_URL'),
    spreeDBName: java.lang.System.getenv('SPREE_DB_NAME'),
    spreeDBUsername: java.lang.System.getenv('SPREE_DB_USERNAME'),
    spreeDBPassword: java.lang.System.getenv('SPREE_DB_PASSWORD'),
    wmsUserId: java.lang.System.getenv('WMS_USER_ID'),
    wmsPassword: java.lang.System.getenv('WMS_PASSWORD')
  }
    switch (env){
      case 'staging':
          config.EnvFulfillmentStage =  'https://happyfresh.fsrv-gw-stage.happyfresh.net/api';
          config.FulfillmentTokenStage = '76d6qGkKE84X89Kn62U71D1YDyerd8oJ';
          config.SNDstockLocationID = '140';
          config.SNDlat = '-6.253253';
          config.SNDlon = '106.801583';
          break;
      case 'sandbox':
          config.EnvFulfillmentStage =  'https://carbon.fsrv-gw-sandbox.happyfresh.net/api';
          config.FulfillmentTokenStage = 'A7NN5o2QHKsQGaEazn6lSPCU5H4dAwThDd7A94';
          config.SNDstockLocationID = '73';
          config.SNDlat = '-6.3762107';
          config.SNDlon = '106.9129413';
          break;
          }


  if (env == 'dev') {
    // customize
    // e.g. config.foo = 'bar';
  } else if (env == 'e2e') {
    // customize
  }
  var SheetDbCsvName = null;
  try {
    var SheetDbCsvName = karate.tagValues.SheetDbCsvName[0];
  } catch (err) {
        if (err instanceof TypeError){
          karate.log('This test session is using local test data')
        } else {
          throw err;
        }
  }
  if (SheetDbCsvName) {
    karate.log('This test session is using SheetDB test data')
    var teamName = karate.tagValues.team[0];
    var sheetName = karate.tagValues.feature[0];
    switch(teamName){
        case 'storm':
            var sheetDbUrl = config.StormSheetDB;
            break;
    }
    var param = {sheetDbUrl: sheetDbUrl, sheetName: sheetName, fileName: SheetDbCsvName}
    karate.call('classpath:src/test/java/utils/sheet-db-utils.feature', param)
  }
  karate.configure('connectTimeout', 20000);
  karate.configure('readTimeout', 20000);
  karate.configure('ssl', true)
  return config;
}
