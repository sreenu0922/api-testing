package api.custom;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import org.apache.commons.io.FileUtils;
import org.junit.Test;
import utils.AWSS3Utils.AWSS3Utils;

import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class CustomRunner {
    public static void generateReport(String karateOutputPath) {

        Collection<File> jsonFiles = FileUtils.listFiles(new File(karateOutputPath), new String[] { "json" }, true);
        List<String> jsonPaths = new ArrayList(jsonFiles.size());
        jsonFiles.forEach(file -> jsonPaths.add(file.getAbsolutePath()));
        Configuration config = new Configuration(new File("target"), "happyfresh-api");
        ReportBuilder reportBuilder = new ReportBuilder(jsonPaths, config);
        reportBuilder.generateReports();
    }

    @Test
    public void runTestParallel() {
        System.setProperty("karate.config.dir", "src/test/java/api/custom");
        System.setProperty("karate.env","custom");
        Results results = Runner.path("classpath:api/custom")
                .tags("@custom=create-order-complete")
                .parallel(1);
        generateReport(results.getReportDir());
        System.clearProperty("karate.env");
        AWSS3Utils.sendReportToS3();
        assertEquals(results.getErrorMessages(), 0, results.getFailCount());
    }


}
