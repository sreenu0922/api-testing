function fn(){
    var data = {
        EnvStage: 'https://stage-api.happyfresh.com/api',
        SpreeStockLocationId: karate.properties['SPREE_STOCK_LOCATION_ID'] || 58,
        UserEmail: karate.properties['USER_EMAIL'] || 'carbon@fri.fyi',
        PasswordEmail: karate.properties['PASSWORD_EMAIL'] || 123456,
        VariantId: karate.properties['VARIANT_ID'] || 32305,
        Quantity: karate.properties['QUANTITY'] || 10
    }
    karate.log('Using karate-config-custom.js')
    return data;
}