package api.storm.strato.slot_capacity.slot_capacity_stubbing;

import static com.github.tomakehurst.wiremock.client.WireMock.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDateTime;

import api.DataGenerator;

import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import utils.SQLUtils;
import utils.TimeUtils;
import utils.ConverterUtils;

public class SlotCapacityStubbing {
    private static final int kintounPort = Integer.parseInt(System.getenv("KINTOUN_WIREMOCK_PORT"));
    private static final int wmsPort = Integer.parseInt(System.getenv("WMS_WIREMOCK_PORT"));

    public static void initializeDatabaseData(String HfcStockLocationId) throws SQLException {
        String dbUrl = System.getenv("INTEGRATION_TEST_DB_URL");
        String dbName = System.getenv("INTEGRATION_TEST_DB_NAME_STRATO");
        String dbUsername = System.getenv("INTEGRATION_TEST_DB_USERNAME");
        String dbPassword = System.getenv("INTEGRATION_TEST_DB_PASSWORD");

        String dbQuery = "TRUNCATE TABLE whitelisted_stores CASCADE;TRUNCATE TABLE capacity_configs CASCADE;";
        SQLUtils.executeQueryWithoutResponse(dbUrl, dbName, dbUsername, dbPassword, dbQuery);
        String dbQuery2 = "INSERT INTO whitelisted_stores(store_id, name, created_at, updated_at, warehouse_id, warehouse_time_zone, stock_location_id, client_id, supplier_id, modifiers) VALUES (6091006, 'WH-ID-BSD', now(), now(), 'WMD1', 'Asia/Jakarta', " + HfcStockLocationId + ", 'HF', 'SUP001', null);";
        SQLUtils.executeQueryWithoutResponse(dbUrl, dbName, dbUsername, dbPassword, dbQuery2);
        String dbQuery3 = "INSERT INTO capacity_configs(id, pick_time, lead_time_minutes, stock_location_id, created_at, updated_at) VALUES (1, 1, 15, " + HfcStockLocationId + ", now(), now());";
        SQLUtils.executeQueryWithoutResponse(dbUrl, dbName, dbUsername, dbPassword, dbQuery3);
    }

    public static void mockHfc2226() throws IOException {
        configureFor("localhost", kintounPort);
        stubFor(post(urlEqualTo("/products/availability-check"))
                .willReturn(aResponse()
                        .withStatus(500)
                        .withHeader("Content-Type", "application/json")
                        .withBody("{\"message\":\"Internal Server Error\"}")
                )
        );
        mockWMsListDeliverySlotCapacityEmpty();
        mockWmsStandardListCapacityConfig();
    }

    public static void mockHfc2220() throws IOException {
        LocalDateTime tomorrow = LocalDateTime.now().plusDays(1);
        String tomorrowStr = TimeUtils.formatToIsoDateTime(tomorrow);

        configureFor("localhost", kintounPort);
        stubFor(post(urlEqualTo("/products/availability-check"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("[{\"name\": \"abc\",\"product_code\": \"08881111222900\",\"store_id\": 9000196,\"price\": 10000,"
                    + "\"remaining_by_date_time\": [{\"date_time\": \"" + tomorrowStr + "\",\"remaining\": 9}]}]")
            )
        );
        mockWMsListDeliverySlotCapacityEmpty();
        mockWmsStandardListCapacityConfig();
    }

    public static void mockHfc2221(String timeSlot) throws ParseException, IOException {
        mockWmsStandardListCapacityConfig();
        mockWMsListDeliverySlotCapacityUsed(Arrays.asList(timeSlot));
    }

    public static void mockHfc2218() throws IOException {
        LocalDateTime yesterday = LocalDateTime.now().minusDays(1);
        String yesterdayStr = TimeUtils.formatToIsoDateTime(yesterday);

        configureFor("localhost", kintounPort);
        stubFor(post(urlEqualTo("/products/availability-check"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("[{\"name\": \"abc\",\"product_code\": \"08881111222900\",\"store_id\": 9000196,\"price\": 10000,"
                    + "\"remaining_by_date_time\": [{\"date_time\": \"" + yesterdayStr + "\",\"remaining\": 10}]}]")
            )
        );
        mockWmsStandardListCapacityConfig();
        mockWMsListDeliverySlotCapacityEmpty();
    }

    public static void mockHfc2215AndHfc2200() throws IOException {
        configureFor("localhost", kintounPort);
        stubFor(post(urlEqualTo("/products/availability-check"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("[]")
            )
        );
        mockWmsStandardListCapacityConfig();
        mockWMsListDeliverySlotCapacityEmpty();
    }

    public static void mockHfc2205() throws IOException {
        LocalDateTime dateTime = LocalDateTime.now().plusDays(2);
        String dateTimeStr = TimeUtils.formatToIsoDateTime(dateTime);

        configureFor("localhost", kintounPort);
        stubFor(post(urlEqualTo("/products/availability-check"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("[{\"name\": \"abc\",\"product_code\": \"08881111222900\",\"store_id\": 9000196,\"price\": 10000,"
                    + "\"remaining_by_date_time\": [{\"date_time\": \"" + dateTimeStr + "\",\"remaining\": 9}]}]")
            )
        );
        mockWmsStandardListCapacityConfig();
        mockWMsListDeliverySlotCapacityEmpty();
    }

    public static void mockHfc2198() throws IOException {
        LocalDateTime dateTime = LocalDateTime.now().plusDays(2);
        String dateTimeStr = TimeUtils.formatToIsoDateTime(dateTime);

        configureFor("localhost", kintounPort);
        stubFor(post(urlEqualTo("/products/availability-check"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("[{\"name\": \"abc\",\"product_code\": \"08881111222900\",\"store_id\": 9000196,\"price\": 10000,"
                    + "\"remaining_by_date_time\": [{\"date_time\": \"" + dateTimeStr + "\",\"remaining\": 10}]},"
                    + "{\"name\": \"abc\",\"product_code\": \"08881111222666\",\"store_id\": 9000196,\"price\": 10000,"
                    + "\"remaining_by_date_time\": [{\"date_time\": \"" + dateTimeStr + "\",\"remaining\": 5}]}]")
            )
        );
        mockWmsStandardListCapacityConfig();
        mockWMsListDeliverySlotCapacityEmpty();
    }

    public static void mockHfc2199(List<String> timeSlot) throws ParseException, IOException {
        mockKintounCheckAvailabilityThreeProducts(timeSlot);
        mockWmsStandardListCapacityConfig();
        mockWMsListDeliverySlotCapacityUsed(timeSlot);
    }

    public static void mockHFC2217(String timeSlot)
        throws ParseException, IOException {
        List<String> timeSlotList = new ArrayList<>();
        timeSlotList.add(timeSlot);
        mockKintounCheckAvailabilityThreeProducts();
        mockWMsListDeliverySlotCapacityUsed(timeSlotList);
        mockWmsStandardListCapacityConfig();
    }

    public static void mockHFC2202(List<String> timeSlots)
            throws ParseException, IOException {
        mockKintounCheckAvailabilityThreeProducts();
        mockWMsListDeliverySlotCapacityUsed(timeSlots);
        mockWmsStandardListCapacityConfig();
    }

    public static void mockHfc2206(List<String> timeSlots) throws ParseException, IOException {
        mockWmsStandardListCapacityConfig();
        mockWMsListDeliverySlotCapacityUsed(timeSlots);
    }

    private static void mockKintounCheckAvailabilityThreeProducts(List<String> timeSlots) {
        configureFor("localhost", kintounPort);
        ZoneId zoneId = ZoneId.of("Asia/Jakarta");
        List<String> zonedDateTimes = timeSlots.stream()
                        .map(timeSlot -> LocalDateTime.parse(timeSlot, DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")))
                        .map(localDateTime -> localDateTime.atZone(ZoneOffset.UTC).withZoneSameInstant(zoneId))
                        .map(zonedDateTime -> zonedDateTime.truncatedTo(ChronoUnit.DAYS).withZoneSameInstant(ZoneOffset.UTC))
                        .map(truncatedDateTime -> truncatedDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")))
                        .distinct()
                        .collect(Collectors.toList());

        stubFor(post(urlEqualTo("/products/availability-check"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(
                                "[{\"name\": \"abc\",\"product_code\": \"08881111222900\",\"store_id\": 9000196,\"price\": 10000,"
                                        + "\"remaining_by_date_time\": ["
                                        + "{\"date_time\": \"" + zonedDateTimes.get(0) + "\",\"remaining\": 10},"
                                        + "{\"date_time\": \"" + zonedDateTimes.get(1) + "\",\"remaining\": 10}]},"
                                        + "{\"name\": \"abc\",\"product_code\": \"08881111222666\",\"store_id\": 9000196,\"price\": 10000,"
                                        + "\"remaining_by_date_time\": ["
                                        + "{\"date_time\": \"" + zonedDateTimes.get(0) + "\",\"remaining\": 5},"
                                        + "{\"date_time\": \"" + zonedDateTimes.get(1) + "\",\"remaining\": 5}]},"
                                        + "{\"name\": \"abc\",\"product_code\": \"08881111222555\",\"store_id\": 9000196,\"price\": 10000,"
                                        + "\"remaining_by_date_time\": ["
                                        + "{\"date_time\": \"" + zonedDateTimes.get(0) + "\",\"remaining\": 5},"
                                        + "{\"date_time\": \"" + zonedDateTimes.get(1) + "\",\"remaining\": 5}]}]"
                        )
                )
        );
    }

    private static void mockKintounCheckAvailabilityThreeProducts() {
        LocalDateTime dateTime = LocalDateTime.now().plusDays(2);
        String dateTimeStr = TimeUtils.formatToIsoDateTime(dateTime);

        configureFor("localhost", kintounPort);
        stubFor(post(urlEqualTo("/products/availability-check"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody(
                    "[{\"name\": \"abc\",\"product_code\": \"08881111222900\",\"store_id\": 9000196,\"price\": 10000,"
                        + "\"remaining_by_date_time\": [{\"date_time\": \"" + dateTimeStr
                        + "\",\"remaining\": 10}]},"
                        + "{\"name\": \"abc\",\"product_code\": \"08881111222666\",\"store_id\": 9000196,\"price\": 10000,"
                        + "\"remaining_by_date_time\": [{\"date_time\": \"" + dateTimeStr
                        + "\",\"remaining\": 5}]},"
                        + "{\"name\": \"abc\",\"product_code\": \"08881111222555\",\"store_id\": 9000196,\"price\": 10000,"
                        + "\"remaining_by_date_time\": [{\"date_time\": \"" + dateTimeStr
                        + "\",\"remaining\": 5}]}]")
            )
        );
    }

    private static void mockWMsListDeliverySlotCapacityEmpty() {
        configureFor("localhost", wmsPort);
        stubFor(get(urlPathEqualTo("/ws/cws/listDeliverySlotCapacity"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\"data\":[]}")
            )
        );
    }

    private static void mockWMsListDeliverySlotCapacityUsed(List<String> timeSlots)
        throws ParseException, JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        ArrayNode dataNode = mapper.createArrayNode();
        for (String time: timeSlots) {
            String formattedTime = TimeUtils.addMinutes(time, 0, "yyyy-MM-dd'T'HH:mm:ss'Z'", "dd/MM/yyyy HH:mm");
            ObjectNode node = mapper.createObjectNode();
            node.put("wh_id", "WMD12");
            node.put("tot_ord_cnt", 10);
            node.put("line_staged", 0);
            node.put("maxolcap", 150);
            node.put("orderline_capacity", 10);
            node.put("cut_off", formattedTime);
            dataNode.add(node);
        }
        ObjectNode body = mapper.createObjectNode();
        body.set("data", dataNode);

        configureFor("localhost", wmsPort);
        stubFor(get(urlPathEqualTo("/ws/cws/listDeliverySlotCapacity"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody(mapper.writeValueAsString(body))
            )
        );
    }

    private static void mockWmsStandardListCapacityConfig() throws IOException {
        String rootDir = DataGenerator.rootDir();
        String wmsCapacityConfigResponsePath = rootDir + "/src/test/java/api/storm/strato/slot_capacity/slot_capacity_stubbing/wms-capacity-config-response-standard.json";
        configureFor("localhost", wmsPort);
        stubFor(get(urlPathEqualTo("/ws/cws/listCapacityConfig"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody(ConverterUtils.jsonFileToString(wmsCapacityConfigResponsePath))
            )
        );
    }
}
