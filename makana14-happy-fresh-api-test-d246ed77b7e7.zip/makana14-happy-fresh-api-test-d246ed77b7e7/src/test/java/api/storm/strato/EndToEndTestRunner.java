package api.storm.strato;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import org.apache.commons.io.FileUtils;
import org.junit.Test;
import utils.AWSS3Utils.AWSS3Utils;
import utils.XrayUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class EndToEndTestRunner {

    private static final String StormBoardId = "126";
    private static final String StormProjectId = "12832";
    private static final String StormTestExecutionTypeId = "10309";

    @Test
    public void testParallel() throws Exception {
        Results results = Runner.path("classpath:api/storm/strato")
                .tags("~@unstable").tags("~@ignore").tags("@test-type=end-to-end")
                .parallel(1);
        generateReport(results.getReportDir());
        AWSS3Utils.sendReportToS3();
        importTestResultToJira();
        assertTrue(results.getErrorMessages(), results.getFailCount() == 0);
    }

    public static void importTestResultToJira() throws Exception {
        String clientId = System.getenv("JIRA_CLIENT_ID");
        String clientSecret = System.getenv("JIRA_CLIENT_SECRET");
        String jiraUsername = System.getenv("JIRA_USERNAME");
        String jiraApiToken = System.getenv("JIRA_API_TOKEN");
        String sendTestResult = System.getenv("SEND_REPORT_JIRA");
        if (Boolean.parseBoolean(sendTestResult)) {
            ArrayList<String> testExecutionId = XrayUtils.importResultToJira(StormBoardId, StormProjectId, StormTestExecutionTypeId, clientId, clientSecret);
            for (String id : testExecutionId) {
                XrayUtils.moveTestExecutionToActiveSprint(StormBoardId, id, jiraUsername, jiraApiToken);
                System.out.println("Test Report: https://happyfresh.atlassian.net/browse/" + id );
            }
        }
    }

    public static void generateReport(String karateOutputPath) {
        Collection<File> jsonFiles = FileUtils.listFiles(new File(karateOutputPath), new String[] {"json"}, true);
        List<String> jsonPaths = new ArrayList<>(jsonFiles.size());
        jsonFiles.forEach(file -> jsonPaths.add(file.getAbsolutePath()));
        Configuration config = new Configuration(new File("target"), "happyfresh-api");
        ReportBuilder reportBuilder = new ReportBuilder(jsonPaths, config);
        reportBuilder.generateReports();
    }
}
