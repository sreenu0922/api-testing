package api.storm.strato.va_improvement.va_improvement_stubbing;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static com.github.tomakehurst.wiremock.client.WireMock.moreThanOrExactly;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;

import java.io.IOException;
import java.sql.SQLException;


import utils.SQLUtils;

public class VaImprovementStubbing {
  private static final int wmsPort = Integer.parseInt(System.getenv("WMS_WIREMOCK_PORT"));
  private static final int fulfillmentPort = Integer.parseInt(System.getenv("FULFILLMENT_WIREMOCK_PORT"));

  public static void initStoreToDB(int storeId) throws SQLException {
    String dbUrl = System.getenv("INTEGRATION_TEST_DB_URL");
    String dbName = System.getenv("INTEGRATION_TEST_DB_NAME_STRATO");
    String dbUsername = System.getenv("INTEGRATION_TEST_DB_USERNAME");
    String dbPassword = System.getenv("INTEGRATION_TEST_DB_PASSWORD");

    String dbQuery = "TRUNCATE TABLE whitelisted_stores CASCADE;";
    SQLUtils.executeQueryWithoutResponse(dbUrl, dbName, dbUsername, dbPassword, dbQuery);
    String dbQuery2 = "INSERT INTO whitelisted_stores(store_id, name, created_at, updated_at, warehouse_id, warehouse_time_zone, stock_location_id, client_id, supplier_id, modifiers) VALUES ("+ storeId +", 'WH-ID-BSD', now(), now(), 'WMD1', 'Asia/Jakarta', 129032, 'HF', 'SUP001', null);";
    SQLUtils.executeQueryWithoutResponse(dbUrl, dbName, dbUsername, dbPassword, dbQuery2);
  }

  public static void insertExpressSlotToDB(String orderNumber) throws SQLException {
    String dbUrl = System.getenv("INTEGRATION_TEST_DB_URL");
    String dbName = System.getenv("INTEGRATION_TEST_DB_NAME_STRATO");
    String dbUsername = System.getenv("INTEGRATION_TEST_DB_USERNAME");
    String dbPassword = System.getenv("INTEGRATION_TEST_DB_PASSWORD");

    String dbQuery = "TRUNCATE TABLE express_booked_slots CASCADE;";
    SQLUtils.executeQueryWithoutResponse(dbUrl, dbName, dbUsername, dbPassword, dbQuery);
    String dbQuery2 = "INSERT INTO express_booked_slots(id, order_number, stock_location_id, start_picking, end_picking, created_at, updated_at) VALUES (1, '"+ orderNumber +"', 129032, now() + INTERVAL '2 hour', now() + INTERVAL '3 hour', now(), now());";
    SQLUtils.executeQueryWithoutResponse(dbUrl, dbName, dbUsername, dbPassword, dbQuery2);
  }

  public static void mockCreateOutboundOrder(String downloadSeq) throws IOException {
    configureFor("localhost", wmsPort);
    stubFor(post(urlEqualTo("/ws/integration/api/wms_inbound"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody("{\"downloadSequence\": " + downloadSeq + " }")
        )
    );
  }

  public static void mockListApiTransactions(String downloadSeq) throws IOException {
    configureFor("localhost", wmsPort);
    stubFor(post(urlEqualTo("/ws/cws/listApiTransactions?dwnld_seq=" + downloadSeq))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody("{\"data\":[{\"transaction_date\":\"2022-05-17T23:36:53.000+0000\",\"integration_name\":\"ORDER_INB_IFD\",\"error_flag\":\"FALSE\",\"error_message\":\"\",\"download_sequences\":" + downloadSeq + "}]}")
        )
    );
  }

  public static void mockUpdateOrderStatusToFulfillment(String downloadSeq) throws IOException {
    configureFor("localhost", fulfillmentPort);
    stubFor(post(urlEqualTo("/api/strato/webhook"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody("{\"data\":[]}")
        )
    );
  }

  public static void verifyCreateOutboundOrder(int num) throws InterruptedException {
    customVerify(num, postRequestedFor(urlEqualTo("/ws/integration/api/wms_inbound")));
  }

  public static void customVerify(int num, RequestPatternBuilder requestPatternBuilder) throws InterruptedException {
    int maxRetries = 5;
    while (num != WireMock.findAll(requestPatternBuilder)
            .size() && maxRetries > 0) {
        Thread.sleep(1000);
        maxRetries--;
    }
    WireMock.verify(moreThanOrExactly(num), requestPatternBuilder);
  }
}
