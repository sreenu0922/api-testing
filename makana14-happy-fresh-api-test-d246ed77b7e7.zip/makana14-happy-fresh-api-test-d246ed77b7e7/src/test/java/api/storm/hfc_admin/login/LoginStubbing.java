package api.storm.hfc_admin.login;
import java.time.ZonedDateTime;
import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;

public class LoginStubbing {

    public static void mockHfc1246(){
        configureFor("localhost", Integer.parseInt(System.getenv("GOOGLE_WIREMOCK_PORT")));
        long expiryDate = ZonedDateTime.now().plusDays(1).toEpochSecond();
        String url = "/oauth2/v3/tokeninfo";
        stubFor(
                get(urlPathEqualTo(url))
                        .willReturn(aResponse()
                                .withStatus(200)
                                .withHeader("content-type", "application/json")
                                .withBody("{\"iss\":\"accounts.google.com\",\"azp\":\"googleClientId\",\"aud\":\"23423423423423424\",\"sub\":\"4234234234234234234234\",\"hd\":\"2342423.com\",\"email\":\"test@happyfresh.com\",\"email_verified\":\"true\",\"at_hash\":\"34234234234\",\"name\":\"Some Name\",\"picture\":\"some-url\",\"given_name\":\"Name\",\"family_name\":\"Family Name\",\"locale\":\"en\",\"iat\":\"1632821710\",\"exp\":\"" + expiryDate +"\",\"jti\":\"4sdfsdfdsfg\",\"alg\":\"RS256\",\"kid\":\"asdfasdfasdf\",\"typ\":\"JWT\"}")));
    }
}
