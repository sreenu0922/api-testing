package api.storm.kintoun.minus_qty;

import utils.SQLUtils;

import java.sql.SQLException;

public class MinusQtyStubbing {
    public static void prepareDataHfc2513(int qty, String productCode, int storeId) throws SQLException {
        String[] clearAllDataQuery = { "delete from products;",
                                    "delete from product_lpns;",
                                    "delete from whitelisted_stores;",
                                    "delete from aloha_credentials;"};
        for(String query : clearAllDataQuery) {
            SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                    System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                    System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                    System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                    query);
        }
        String registerCountryQuery = "insert into aloha_credentials (country, api_key, partner_id, created_at, updated_at)\n" +
                "values ('ID', 'apikeyforid', 'partneridforid', now(), now());";
        SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                registerCountryQuery);
        String whitelistStoreQuery = "insert into whitelisted_stores (store_id, name, created_at, updated_at, warehouse_id, country, warehouse_time_zone)\n" +
                "values (" + storeId + ", 'hfc', now(), now(), 'wmd1', 'ID', 'Asia/Jakarta');";
        SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                whitelistStoreQuery);
        String addProductQuery = "insert into products (name, store_id, quantity, product_code, internal_product_code, price, created_at, updated_at)\n" +
                "values ('test product', " + storeId + ", " + qty + ", '" + productCode + "', '" + productCode + "-ID', 10000, now(), now());";
        SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                addProductQuery);
    }
}
