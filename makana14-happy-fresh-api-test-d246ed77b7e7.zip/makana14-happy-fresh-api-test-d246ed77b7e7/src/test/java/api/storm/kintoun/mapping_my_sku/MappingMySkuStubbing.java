package api.storm.kintoun.mapping_my_sku;

import static com.github.tomakehurst.wiremock.client.WireMock.*;

import static org.junit.Assert.assertEquals;

import api.DataGenerator;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import utils.SQLUtils;
import utils.ConverterUtils;

public class MappingMySkuStubbing {

    private static final int wmsPort = Integer.parseInt(System.getenv("WMS_WIREMOCK_PORT"));
    private static final int stratoPort = Integer.parseInt(System.getenv("STRATO_WIREMOCK_PORT"));


    public static void prepareDataHfc1330(String productCode, String internalProductCode, String lpnNumber, int quantity, int storeId)
        throws SQLException {

        String fetchExistingProductQuery = String.format("SELECT id FROM products WHERE product_code = '%s' AND store_id = %d;",
        productCode, storeId);

        List<String> existingProductResult = SQLUtils.executeQuery(System.getenv("INTEGRATION_TEST_DB_URL"),
            System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
            System.getenv("INTEGRATION_TEST_DB_USERNAME"),
            System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
            fetchExistingProductQuery);

        if (existingProductResult.size() != 0){
            int productId = Integer.parseInt(existingProductResult.get(0)); //Assuming the output just "1000000"

            String deleteLPNQuery = String.format("DELETE FROM product_lpns WHERE product_id = '%d';", productId);
    
            SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                deleteLPNQuery);
        }       

        String[] deleteProductsQuery = {
            String.format("DELETE FROM products where product_code = '%s' AND store_id = %d", productCode, storeId),
            String.format("DELETE FROM products where internal_product_code = '%s' AND store_id = %d", internalProductCode, storeId)
        };

        for (String query: deleteProductsQuery) {
            SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                query);
        }
        
        String[] deleteStoreQuery = {
            String.format("DELETE FROM whitelisted_stores where store_id = %d", storeId),
            "DELETE FROM aloha_credentials;"
        };

        for (String query: deleteStoreQuery) {
            SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                query);
        }

        String registerCountryQuery = "insert into aloha_credentials (country, api_key, partner_id, created_at, updated_at)\n" +
                "values ('ID', 'apikeyforid', 'partneridforid', now(), now());";
        SQLUtils.executeQueryWithoutResponse("localhost:5433",
                "kintoun",
                "user",
                "secret",
                registerCountryQuery);      

        String insertStoreQuery = "insert into whitelisted_stores (store_id, name, created_at, updated_at, warehouse_id, country, warehouse_time_zone)\n" +
                "values (" + storeId + ", 'hfc', now(), now(), 'wmd1', 'ID', 'Asia/Jakarta');";
        SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                insertStoreQuery);        

        String insertProductQuery =
            String.format("INSERT INTO products VALUES (1000000, 'test_product', %d, %d, now(), now(), '%s', 10000, '%s')",
                storeId, quantity, productCode, internalProductCode);

        SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
            System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
            System.getenv("INTEGRATION_TEST_DB_USERNAME"),
            System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
            insertProductQuery);


        String fetchProductQuery = String.format("SELECT id FROM products WHERE product_code = '%s' AND store_id = %d;",
            productCode, storeId);

        List<String> result = SQLUtils.executeQuery(System.getenv("INTEGRATION_TEST_DB_URL"),
            System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
            System.getenv("INTEGRATION_TEST_DB_USERNAME"),
            System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
            fetchProductQuery);

        assertEquals(1, result.size());
        int productId = Integer.parseInt(result.get(0)); //Assuming the output just "1000000"
        String createLPNQuery = String.format(
            "INSERT INTO product_lpns VALUES(1000000, now(), now(), '%s', %d, "
                + "now() + interval '1' day, null, '%d');", lpnNumber, quantity, productId);

        SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
            System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
            System.getenv("INTEGRATION_TEST_DB_USERNAME"),
            System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
            createLPNQuery);
    }

    public static void prepareDataHfc3365(String productCode, String internalProductCode, String lpnNumber, int quantity, int storeId)
        throws SQLException, IOException {

        String fetchExistingProductQuery = String.format("SELECT id FROM products WHERE product_code = '%s' AND store_id = %d;",
        productCode, storeId);

        List<String> existingProductResult = SQLUtils.executeQuery(System.getenv("INTEGRATION_TEST_DB_URL"),
            System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
            System.getenv("INTEGRATION_TEST_DB_USERNAME"),
            System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
            fetchExistingProductQuery);

        if (existingProductResult.size() != 0){
            int productId = Integer.parseInt(existingProductResult.get(0)); //Assuming the output just "1000000"

            String deleteLPNQuery = String.format("DELETE FROM product_lpns WHERE product_id = '%d';", productId);
    
            SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                deleteLPNQuery);
        }   

        String[] deleteProductsQuery = {
            String.format("DELETE FROM products where product_code = '%s' AND store_id = %d", productCode, storeId),
            String.format("DELETE FROM products where internal_product_code = '%s' AND store_id = %d", internalProductCode, storeId)
        };

        for (String query: deleteProductsQuery) {
            SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                query);
        }
        
        String[] deleteStoreQuery = {
            String.format("DELETE FROM whitelisted_stores where store_id = %d", storeId),
            "DELETE FROM aloha_credentials;"
        };

        for (String query: deleteStoreQuery) {
            SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                query);
        }

        String registerCountryQuery = "insert into aloha_credentials (country, api_key, partner_id, created_at, updated_at)\n" +
                "values ('ID', 'apikeyforid', 'partneridforid', now(), now());";
        SQLUtils.executeQueryWithoutResponse("localhost:5433",
                "kintoun",
                "user",
                "secret",
                registerCountryQuery);      

        String insertStoreQuery = "insert into whitelisted_stores (store_id, name, created_at, updated_at, warehouse_id, country, warehouse_time_zone)\n" +
                "values (" + storeId + ", 'hfc', now(), now(), 'wmd1', 'ID', 'Asia/Jakarta');";
        SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                insertStoreQuery);        

        String insertProductQuery =
            String.format("INSERT INTO products VALUES (2000000, 'test_product', %d, %d, now(), now(), '%s', 10000, '%s')",
                storeId, quantity, productCode, internalProductCode);

        SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
            System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
            System.getenv("INTEGRATION_TEST_DB_USERNAME"),
            System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
            insertProductQuery);


        String fetchProductQuery = String.format("SELECT id FROM products WHERE product_code = '%s' AND store_id = %d;",
            productCode, storeId);

        List<String> result = SQLUtils.executeQuery(System.getenv("INTEGRATION_TEST_DB_URL"),
            System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
            System.getenv("INTEGRATION_TEST_DB_USERNAME"),
            System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
            fetchProductQuery);

        assertEquals(1, result.size());
        int productId = Integer.parseInt(result.get(0)); //Assuming the output just "1000000"

        String createLPNQuery = String.format(
            "INSERT INTO product_lpns VALUES(2000000, now(), '2021-07-17 07:00:00.904', '%s', %d, "
                + "now() + interval '1' day, null, '%d');", lpnNumber, quantity, productId);

        SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
            System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
            System.getenv("INTEGRATION_TEST_DB_USERNAME"),
            System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
            createLPNQuery);

        mockWmsLpnItemList();
        mockStratoPickList();
    }

    private static void mockWmsLpnItemList() throws IOException {
        String rootDir = DataGenerator.rootDir();
        String wmsCapacityConfigResponsePath = rootDir + "/src/test/java/api/storm/kintoun/mapping_my_sku/wms-lpn-item-list-response.json";
        configureFor("localhost", wmsPort);
        stubFor(get(urlPathEqualTo("/ws/cws/listItemLpns"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody(ConverterUtils.jsonFileToString(wmsCapacityConfigResponsePath))
            )
        );
    }


    private static void mockStratoPickList() throws IOException {
        configureFor("localhost", stratoPort);
        stubFor(get(urlPathEqualTo("/orders/picklist"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("[]")
            )
        );
    }
}
