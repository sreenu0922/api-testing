package api.storm.kintoun.automatic_register_sku;

import utils.SQLUtils;

import java.sql.SQLException;

public class AutomaticRegisterSkuStubbing {
    public static void prepareDataHfc891() throws SQLException {
        String clearAllDataQuery = "delete from products;";
        SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                clearAllDataQuery);
        String insertProductQuery = "insert into products (name, store_id, quantity, product_code, internal_product_code, price, created_at, updated_at)\n" +
                "values ('test product', '9000', 5, '2001009246541', '2001009246541-ID', 10000, now(), now());";
        SQLUtils.executeQueryWithoutResponse(System.getenv("INTEGRATION_TEST_DB_URL"),
                System.getenv("INTEGRATION_TEST_DB_NAME_KINTOUN"),
                System.getenv("INTEGRATION_TEST_DB_USERNAME"),
                System.getenv("INTEGRATION_TEST_DB_PASSWORD"),
                insertProductQuery);
    }
}
