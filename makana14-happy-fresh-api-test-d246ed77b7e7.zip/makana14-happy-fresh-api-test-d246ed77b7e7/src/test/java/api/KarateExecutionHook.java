package api;

import com.intuit.karate.Results;
import com.intuit.karate.core.*;
import com.intuit.karate.http.HttpRequestBuilder;

public class KarateExecutionHook implements ExecutionHook {
    @Override
    public boolean beforeScenario(Scenario scenario, ScenarioContext scenarioContext) {
        return false;
    }

    @Override
    public void afterScenario(ScenarioResult scenarioResult, ScenarioContext scenarioContext) {

    }

    @Override
    public boolean beforeFeature(Feature feature, ExecutionContext executionContext) {
        return false;
    }

    @Override
    public void afterFeature(FeatureResult result, ExecutionContext context) {

    }

    @Override
    public void beforeAll(Results results) {

    }

    @Override
    public void afterAll(Results results) {

    }

    @Override
    public boolean beforeStep(Step step, ScenarioContext scenarioContext) {
        return false;
    }

    @Override
    public void afterStep(StepResult stepResult, ScenarioContext scenarioContext) {

    }

    @Override
    public String getPerfEventName(HttpRequestBuilder httpRequestBuilder, ScenarioContext scenarioContext) {
        return null;
    }

    @Override
    public void reportPerfEvent(PerfEvent perfEvent) {

    }
}
