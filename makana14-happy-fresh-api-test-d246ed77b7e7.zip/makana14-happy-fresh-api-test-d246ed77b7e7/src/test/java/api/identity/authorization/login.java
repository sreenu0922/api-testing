package api.identity.authorization;

import com.intuit.karate.KarateOptions;
import com.intuit.karate.junit4.Karate;
import org.junit.runner.RunWith;

@RunWith(Karate.class)
@KarateOptions(
        features = "classpath:api/authorization/login.feature", tags = "~@ignore"
)
public class login {
}
