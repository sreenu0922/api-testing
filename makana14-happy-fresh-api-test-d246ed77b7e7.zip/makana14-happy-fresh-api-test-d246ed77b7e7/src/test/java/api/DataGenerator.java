package api;

import com.github.javafaker.Faker;

import java.time.LocalDate;
import java.util.Date;

public class DataGenerator {
    private static Faker faker = new Faker();
    private static LocalDate now;

    public static String code() { return "h" + faker.number().digits(4); }
    public static String name() { return "TE" + faker.number().digits(3) + "qa"+ faker.number().digits(2) ; }
    public static String nameStatictest() { return "TE" + " StaticTest "+faker.number().digits(6) ; }
    public static String nameBank() { return "TE" + " BankTest "+faker.number().digits(6) ; }
    public static String nameBrand() { return "TE" + "-BrandTest-"+faker.number().digits(6) ; }
    public static String nameInitial() { return "TE " + faker.number().digits(5); }
    public static String customeUrl() { return "www.te-seotest" + faker.number().digits(6) + ".com"; }
    public static String customeNewUrl() { return "www.te-" + faker.number().digits(6) + ".com/test"; }
    public static String customeUrlRedirection() { return "https://te-seotest.bhinneka.com/" + faker.number().digits(4); }
    public static String slugInitial() { return "te-" + faker.name().lastName().toLowerCase()+"-"+ faker.number().digits(5); }
    public static String name20() { return "TE" + faker.number().digits(18); }
    public static String name30() { return "TE" + faker.number().digits(28); }
    public static String name50() { return "TE" + faker.number().digits(48); }
    public static String nameBrand0() { return "te" + "-brandtest-"+faker.number().digits(6) ; }
    public static String nameBrand20() { return "te-" + faker.number().digits(17); }
    public static String nameBrand30() { return "te-" + faker.number().digits(27); }
    public static String nameBrand50() { return "te-" + faker.number().digits(47); }
    public static String name151() { return "TE" + faker.number().digits(149); }
    public static String nameCategory() { return "TE-Category" + faker.number().digits(4) + "QA"+ faker.number().digits(2) ; }
    public static String url() { return faker.internet().url(); }
    public static String description() { return String.valueOf(faker.lorem().sentences(2)); }
    public static String email() { return faker.internet().emailAddress(); }
    public static String rating() { return faker.number().digits(1); }
    public static String title() { return faker.company().profession(); }
    public static String company() { return faker.company().name(); }
    public static String street() { return faker.address().streetName(); }
    public static String content() { return faker.animal().name(); }
    public static String keyword() { return faker.ancient().hero(); }
    public static String sku() { return "sku" + faker.number().digits(5); }
    public static String ip() { return "128.0.0." + faker.number().digits(1); }
    public static String variant() { return "var" + faker.ancient().hero() + faker.number().digits(3); }
    public static String codeNumber() { return faker.number().digits(3); }
    public static String code4Digit() { return faker.number().digits(4); }
    public static String userName() { return faker.name().username(); }
    public static String lorem205() { return String.valueOf(faker.lorem().sentences(205)); }
    public static String lorem260() { return String.valueOf(faker.lorem().sentences(260)); }
    public static String number50() { return faker.number().digits(50); }
    public static String lorem350() { return String.valueOf(faker.lorem().words(350)); }
    public static String qty2() { return faker.number().digits(2); }
    public static String nameTE() { return "TE-Test-" + faker.number().digits(5); }
    public static String currentDate() { return LocalDate.now().plusDays(4).toString();}
    public static String timeMillis() { Date date = new Date(); return String.valueOf(date.getTime());}
    public static String dateNow() { return LocalDate.now().toString(); }
    public static String rootDir() { return System.getProperty("user.dir");}
    public static String currentDatePlus(int additionalDate) {return LocalDate.now().plusDays(additionalDate).toString();};
}
