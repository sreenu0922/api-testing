package utils;

import api.DataGenerator;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.json.JSONObject;


import java.util.ArrayList;
import java.util.List;


/**
 * Utility class for Catalog Team
 */
public class CatalogUtils {
    static final String catalogDbConfig = "mongodb+srv://walle:walle@productcatalog0-nnwcx.mongodb.net/test?authSource=admin&replicaSet=ProductCatalog0-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true";
    static final String[] csv_header = {
            "Product_Code",
            "EAN",
            "Brand",
            "Product_Name",
            "Description",
            "Brand_LL",
            "Product_Name_LL",
            "Description_LL",
            "Category1",
            "Category2",
            "Group",
            "VAT",
            "Packaging_Qty",
            "Size_net",
            "Unit",
            "Height",
            "Weight",
            "Width",
            "Depth",
            "Length",
            "Natural_Unit",
            "Avg_Weight",
            "Sell_Natural",
            "Unit_Pieces",
            "Supermarket_Unit",
            "Country",
            "keyword",
            "product_type",
            "Attribute1",
            "Attribute2",
            "Attribute3",
            "Supermarket_ID",
            "Dummy_Product",
            "Max_Order_Quantity",
            "Sellable_Items"
    };
    static String[] csv_value = {
            "",
            "",
            "Hfc",
            "Buah Anti Lapar",
            "Sekali makan tidak akan lapar lagi",
            "Awan Senang Segar",
            "Buah Anti Lapar Awan Senang Segar",
            "new product from hfc indonesia",
            "product-local/traditional-food",
            "",
            "",
            "0.05",
            "10",
            "10",
            "g",
            "4.5",
            "2",
            "6.5",
            "7.5",
            "8.5",
            "",
            "",
            "FALSE",
            "1",
            "g",
            "ID",
            "Buah",
            "product_local/traditional_sweets",
            "",
            "",
            "",
            "ID-RM-PI",
            "FALSE",
            "",
            "all_users"
    };

    /**
     * Generate StringList of csv data for onboard product in catalog dashboard
     * with following template: csv_header & csv_value (only product_code can be changed)
     * @param product_code  SKU's product_code
     * @return List of csv data
     */
    public static List<String[]> createOnboardProductCsvData(String product_code, String country) {
        String[] header = csv_header;
        String[] value = csv_value;
        csv_value[0] = product_code;
        csv_value[1] = product_code + "-HF-" + country;
        List<String[]> list = new ArrayList<>();
        list.add(csv_header);
        list.add(csv_value);
        return list;
    }

    /**
     * Generate onboard product csv filename based on template from Catalog dashboard
     * @return CSV filename
     */
    public static String generateOnboardProductCsvFileName(){
        return "product-import-upload(Onboarding)" + DataGenerator.dateNow() + ".csv";
    }

    /**
     * Generate unique product code with time millis
     * @param prefix Product code's prefix
     * @return Unique product code: Prefix + time millis
     */
    public static String generateProductCode(String prefix){
        return prefix + DataGenerator.timeMillis();
    }

    /**
     * Get Catalog admin token from Catalog DB
     * with Database name: staging and collection name: users
     * @param email registered email on Catalog admin
     * @return Catalog admin token
     */
    public static String getCatalogAdminToken(String email) {
        MongoClient mongoClient = MongoClients.create(catalogDbConfig);
        MongoDatabase database = mongoClient.getDatabase("staging");
        MongoCollection<Document> collection = database.getCollection("users");
        System.out.println(collection.countDocuments());
        Document myDoc = collection.find(Filters.eq("g_email", email)).first();
        String jsonString = myDoc.toJson();
        JSONObject jsonObject = new JSONObject(jsonString);
        return jsonObject.get("g_token").toString();
    }
}
