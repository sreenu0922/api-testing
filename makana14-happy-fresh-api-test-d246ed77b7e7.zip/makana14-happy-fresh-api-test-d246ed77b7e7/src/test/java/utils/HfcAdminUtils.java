package utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for Hfc Admin
 */
public class HfcAdminUtils {
    static final String[] csv_header = {
            "Store Number",
            "Barcode",
            "Product Description",
            "Normal Price"
    };
    static final String[] csv_value = {
            "9000196",
            "",
            "",
            ""
    };

    /**
     * Create CSV for update PNQ
     * @param productCode product code
     * @param description description of product
     * @param normalPrice normal price of product code
     * @return list of csv data
     */
    public static List<String[]> createUpdatePNQCsvData(String productCode, String description, String normalPrice){
        csv_value[1] = productCode;
        csv_value[2] = description;
        csv_value[3] = normalPrice;
        List<String[]> list = new ArrayList<>();
        list.add(csv_header);
        list.add(csv_value);
        return list;
    }

}
