package utils;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;
import java.util.TimeZone;
import org.apache.commons.lang.time.DateUtils;

/**
 * Utility class for Time
 */
public class TimeUtils {
    public static final long HOUR = 3600*1000; // in milli-seco
    public static final long MINUTE = 60*1000; // in milli-seco

    /**
     * Get UTC time with additional hour
     * @param additionalHour hour to be added
     * @return String of current time with additional hour
     */
    public static String getUtcTimeWithAdditionalHour(int additionalHour, String dateFormat){
        SimpleDateFormat outputFormat = new SimpleDateFormat("HH:mm:ssXXX");
        if (dateFormat != "" || !Objects.nonNull(dateFormat)) {
            outputFormat = new SimpleDateFormat(dateFormat);
        }

        outputFormat.setTimeZone(TimeZone.getTimeZone("Asia/Jakarta"));
        Date date1 = new Date(new Date().getTime() + additionalHour * HOUR);
        return outputFormat.format(DateUtils.round(date1, Calendar.HOUR));
    }

    /**
     * Add minutes to given time
     * @param currentTime current time
     * @param additionalMinutes minutes to be added
     * @param inputTimeFormat time format of current time
     * @param outputTimeFormat time format of result
     * @return currentTime + additionalMinutes with outputTimeFormat
     * @throws ParseException exception for error parsing
     */
    public static String addMinutes(String currentTime, double additionalMinutes, String inputTimeFormat, String outputTimeFormat) throws ParseException {
        SimpleDateFormat inputFormat = new SimpleDateFormat(inputTimeFormat);
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputTimeFormat);
        Date date = inputFormat.parse(currentTime);
        Date result = new Date(date.getTime() + (int) (additionalMinutes * MINUTE));
        return outputFormat.format(result);
    }

    /**
     * Convert given date time to string into ISO format (2022-02-18T14:00:00Z)
     * @param dateTime time wished to be converted
     * @return string of given time
     */
    public static String formatToIsoDateTime(LocalDateTime dateTime) {
        DateTimeFormatter formatter =  DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
        return dateTime.format(formatter);
    }
}
