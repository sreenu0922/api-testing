package utils;

import org.jsontocsv.writer.CSVWriter;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;


/**
 * Utility class for converting data / file
 */
public class ConverterUtils {
    /**
     * Convert JSON data to CSV File,
     * and store the file to src/test/resources
     * @param flatJson  JSON data without nested value
     * @param filename  ex: <filename>.csv
     */
    public static void jsonToCsvFile(List flatJson, String filename){
        CSVWriter.writeToFile(CSVWriter.getCSV(flatJson, ","), "src/test/resources/" + filename);
    }

    /**
     * Convert ArrayList data to CSV File
     * @param csvData   CSV Data with ArrayList format
     * @param filepath  filepath should be consist of dir + <filename>.csv
     * @throws IOException
     */
    public static void arrayListToCsvFile(List<String[]> csvData, String filepath) throws IOException {
        try (com.opencsv.CSVWriter writer = new com.opencsv.CSVWriter(new FileWriter(filepath))) {
            writer.writeAll(csvData);
        }
    }

    /**
     * Convert local time to GMT
     * @param localTime with format HH:mm:ssXXX. Example: 07:00:00+07:00
     * @return String of date with format HH:mm:ssZ
     * @throws ParseException
     */
    public static String localTimeToGmt(String localTime) throws ParseException {
        SimpleDateFormat inputFormat = new SimpleDateFormat("HH:mm:ssXXX");
        SimpleDateFormat outputFormat = new SimpleDateFormat( "HH:mm:ss" );
        outputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date dateObj = inputFormat.parse( localTime );
        return outputFormat.format(dateObj) + 'Z';
    }

    /**
     * Convert file with .txt extension to String
     * @param fileName path + filename
     * @return String of file's content
     * @throws Exception
     */
    public static String txtFileToString(String fileName) throws IOException {
        try {
            String data = "";
            data = new String(Files.readAllBytes(Paths.get(fileName)));
            return data;
        } catch (IOException ioException) {
            throw ioException;
        }

    }

    /**
     * Convert Json file to String
     * @param jsonFilePath json file path in String
     * @return Json String
     * @throws IOException
     */
    public static String jsonFileToString(String jsonFilePath) throws IOException {
        return new String(Files.readAllBytes(Paths.get(jsonFilePath)));
    }
}
