package utils;

import java.sql.*;
import java.util.ArrayList;

public class SQLUtils {

    /**
     * Connect and execute non edit query (like SELECT) on postgresql
     * @param dbUrl DB Url + port
     * @param dbName DB Name
     * @param dbUser Username to connect
     * @param dbPassword Password to connect
     * @param query Query to be executed
     * @return ArrayList of all row's value
     * @throws SQLException
     */
    public static ArrayList<String> executeQuery(String dbUrl, String dbName, String dbUser, String dbPassword, String query) throws SQLException {
        ArrayList<String> values = new ArrayList<>();
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found " + e);
        }
        String URL = String.format("jdbc:postgresql://%s/%s", dbUrl, dbName);
        try {
            connection = DriverManager.getConnection(URL, dbUser, dbPassword);
            statement = connection.createStatement();
            resultSet = statement.executeQuery(query);
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            int totalColumn = resultSetMetaData.getColumnCount();
            while (resultSet.next()){
                for(int index = 1; index<=totalColumn; index++){
                    values.add(resultSet.getString(index));
                }
            }
        } finally {
            if (resultSet != null){
                resultSet.close();
            }
            if (statement != null){
                statement.close();
            }
            if (connection != null){
                connection.close();
            }
        }
        return values;
    }

    /**
     * Connect and execute edit query (like DELETE) on postgresql
     * @param dbUrl DB Url + port
     * @param dbName DB Name
     * @param dbUser Username to connect
     * @param dbPassword Password to connect
     * @param query Query to be executed
     * @throws SQLException
     */
    public static void executeQueryWithoutResponse(String dbUrl, String dbName, String dbUser, String dbPassword, String query) throws SQLException {
        String URL = String.format("jdbc:postgresql://%s/%s", dbUrl, dbName);
        Connection connection = null;
        Statement statement = null;
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found " + e);
        }
        try {
            connection = DriverManager.getConnection(URL, dbUser, dbPassword);
            statement = connection.createStatement();
            statement.execute(query);
        } catch (Exception exception){
            exception.printStackTrace();
        } finally {
            if (statement != null){
                statement.close();
            }
            if (connection != null){
                connection.close();
            }
        }

    }

    /**
     * Do SELECT query and retry until expected result is exist until specific index
     * @param indexResult index of expected result
     * @param loopUntil max index
     * @param expectedValue expected result
     * @param dbUrl DB url
     * @param dbName DB name
     * @param dbUsername DB username
     * @param dbPassword DB password
     * @param dbQuery DB query
     * @throws SQLException
     */
    public static void retrySelectUntilExpectedValue(int indexResult, int loopUntil, String expectedValue, String dbUrl, String dbName, String dbUsername, String dbPassword, String dbQuery) throws SQLException {
        int index = 0;
        ArrayList<String> sqlResult;
        System.out.println("dbQuery: " + dbQuery);
        System.out.println("loop until: " + loopUntil);
        do {
            index += 1;
            sqlResult = executeQuery(dbUrl, dbName, dbUsername, dbPassword, dbQuery);
            System.out.println("sqlResult: " + sqlResult);
            System.out.println("index: " + index);
            System.out.println(sqlResult.size() >= indexResult ? sqlResult.get(indexResult) : "");
            if(index == loopUntil){
                throw new SQLException("This query: " + dbQuery + " doesn't return expected value after loop " + loopUntil + "x. Expected: " + expectedValue + ". Actual: " + sqlResult);
            }
        } while ((sqlResult.size() <= 0 || !sqlResult.get(indexResult).equals(expectedValue)) & index < loopUntil);
    }

    /**
     * Select and retry until value is not null
     * @param loopUntil retry until loopUntil
     * @param dbUrl Url of db
     * @param dbName Name of db
     * @param dbUsername Username of db
     * @param dbPassword Password of db
     * @param dbQuery Query of db
     * @return
     * @throws SQLException
     */
    public static ArrayList<String> retrySelectUntilReturnValue(int loopUntil, String dbUrl, String dbName, String dbUsername, String dbPassword, String dbQuery) throws SQLException {
        ArrayList<String> sqlResult = null;
        int index = 0;
        do {
            index += 1;
            sqlResult = executeQuery(dbUrl, dbName, dbUsername, dbPassword, dbQuery);
            if(index == loopUntil){
                throw new SQLException("Value is not exist after retry.");
            }
        } while (sqlResult.size() == 0 && index < loopUntil );
        return sqlResult;
    }
}
