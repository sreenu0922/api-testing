package utils;

import api.DataGenerator;
import com.google.common.collect.Lists;
import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Utility class for Cloud Xray REST API
 */
public class XrayUtils {
    private static final String XRAY_BASE_URL = "https://xray.cloud.getxray.app/api/v2";
    private static final String JIRA_BASE_URL = "https://happyfresh.atlassian.net";
    private static final String StormProjectId = "12832";
    private static final String StormTestExecutionTypeId = "10309";
    private static final String StormBoardId = "126";
    public static final MediaType JSON
            = MediaType.parse("application/json; charset=utf-8");

    public static void main(String[] args) throws Exception {
        ArrayList<String> testExecutionId = importResultToJira(StormBoardId, StormProjectId, StormTestExecutionTypeId, System.getenv("JIRA_CLIENT_ID"), System.getenv("JIRA_CLIENT_SECRET"));
        for (int i=0; i<testExecutionId.size(); i++){
            moveTestExecutionToActiveSprint("126", testExecutionId.get(i), System.getenv("JIRA_USERNAME"), System.getenv("JIRA_API_TOKEN"));
        }
    }

    /**
     * Get XRAY Auth Token
     * @return token
     * @throws IOException
     */
    public static String getToken(String clientId, String clientSecret) throws IOException {
        RequestBody formBody = new FormBody.Builder()
                .add("client_id", clientId)
                .add("client_secret", clientSecret)
                .build();
        Request request = new Request.Builder()
                .url(XRAY_BASE_URL + "/authenticate")
                .post(formBody)
                .build();
        OkHttpClient client = new OkHttpClient();
        Response response = client.newCall(request).execute();
        String responseBody = response.body().string();
        assert response.code() == 200;
        return responseBody.substring(1, responseBody.length() - 1);
    }

    /**
     * Import XRAY test execution result based on Cucumber JSON report
     * @param projectId Project id
     * @param issueTypeId
     * @param clientId ira/Confluence Client ID (request to Confluence Admin)
     * @param clientSecret Jira/Confluence Client Secret (request to Confluence Admin)
     * @throws Exception
     */
    public static ArrayList<String> importResultToJira(String boardId, String projectId, String issueTypeId, String clientId, String clientSecret) throws IOException {
        String rootDir = DataGenerator.rootDir();
        String testInfoPath =  rootDir + "/src/test/resources/test-info.json";
        String resultTxtPath = rootDir + "/target/surefire-reports/results-json.txt";
        ArrayList<String> jsonReports = getAllCucumberJsonReport();
        ArrayList<String> testExecutionIdList = new ArrayList<>();
        String token = getToken(clientId, clientSecret);
        for(String jsonReport : jsonReports){
            String resultPath = DataGenerator.rootDir() + "/target/surefire-reports/" + jsonReport;
            String[] fullFileName = jsonReport.split("\\.");
            String featureFileName = "[" + fullFileName[fullFileName.length - 2] + "]";
            String testResult = ConverterUtils.txtFileToString(resultTxtPath);
            if(testResult.contains("\"failures\":null")) {
                testResult = "[PASS]";
            } else {
                testResult = "[FAILED]";
            }
            generateTestInfo(projectId, "[AT]" + testResult + featureFileName, issueTypeId, boardId);
            RequestBody formBody = new MultipartBody.Builder()
                    .addFormDataPart("results",
                            jsonReport,
                            RequestBody.create(new File(resultPath), MediaType.parse("text/json")))
                    .addFormDataPart("info",
                            "test-info.json",
                            RequestBody.create(new File(testInfoPath), MediaType.parse("text/json")))
                    .setType(MultipartBody.FORM)
                    .build();
            Request request = new Request.Builder()
                    .addHeader("Content-Type", "multipart/form-data")
                    .addHeader("Authorization", "Bearer " + token)
                    .post(formBody)
                    .url(XRAY_BASE_URL + "/import/execution/cucumber/multipart")
                    .build();
            OkHttpClient client = new OkHttpClient();
            Response response = client.newCall(request).execute();
            String responseBody = response.body().string();
            JSONObject jsonObject = new JSONObject(responseBody);
            testExecutionIdList.add(jsonObject.getString("key"));
            assert response.code() == 200;
        }
        return testExecutionIdList;
    }

    /**
     * Generate test-info.json
     * @param projectId Project id
     * @param projectSummary Test Execution Title
     * @param issueTypeId
     * @param boardId Board id
     * @throws IOException
     */
    public static void generateTestInfo(String projectId, String projectSummary, String issueTypeId, String boardId) throws IOException {
        String filepath = DataGenerator.rootDir() + "/src/test/resources/test-info.json";
        JSONObject jsonObject = new JSONObject()
                .put("fields", new JSONObject()
                    .put("project", new JSONObject()
                        .put("id", projectId))
                    .put("summary", projectSummary)
                    .put("issuetype", new JSONObject()
                        .put("id", issueTypeId)))
                .put("xrayFields", new JSONObject());
        try {
            FileWriter file = new FileWriter(filepath);
            file.write(jsonObject.toString());
            file.close();
        } catch (IOException ioException){
            throw ioException;
        }

    }

    /**
     * Get all cucumber json report in target/surefire-reports
     * @return ArrayList of cucumber json report file name
     */
    public static ArrayList<String> getAllCucumberJsonReport(){
        ArrayList<String> jsonReports = new ArrayList<String>();
        String reportDirectory = DataGenerator.rootDir() + "/target/surefire-reports";
        File folder = new File(reportDirectory);
        File[] listOfFiles = folder.listFiles();
        for (File file : listOfFiles) {
            if (file.isFile()) {
                String filename = file.getName();
                int extensionIndex = filename.lastIndexOf(".");
                if (filename.substring(extensionIndex).equals(".json")) {
                    jsonReports.add(filename);
                }
            }
        }
        return jsonReports;
    }

    /**
     * Get Active Sprint Id for given board id
     * @param boardId team's board id
     * @param jiraUsername email address for jira username
     * @param jiraApiToken visit https://id.atlassian.com/manage-profile/security/api-tokens to generate your token
     * @return String of active sprint id
     * @throws IOException
     */
    public static String getActiveSprintId(String boardId, String jiraUsername, String jiraApiToken) throws IOException {
        String credential = Credentials.basic(jiraUsername, jiraApiToken);
        Request request = new Request.Builder()
                .addHeader("Authorization", credential)
                .get()
                .url(JIRA_BASE_URL + "/rest/agile/1.0/board/" + boardId + "/sprint?state=active")
                .build();
        OkHttpClient client = new OkHttpClient();
        Response response = client.newCall(request).execute();
        String responseBody = response.body().string();
        assert response.code() == 200;
        JSONObject jsonObject = new JSONObject(responseBody);
        JSONArray jsonArray = jsonObject.getJSONArray("values");
        return Integer.toString(jsonArray.getJSONObject(0).getInt("id"));
    }

    /**
     * @param boardId team's board id
     * @param testExecutionId id of test execution. ex: HFC-xxxx, HST-yyyy
     * @param jiraUsername email address for jira username
     * @param jiraApiToken visit https://id.atlassian.com/manage-profile/security/api-tokens to generate your token
     * @throws IOException
     */
    public static void moveTestExecutionToActiveSprint(String boardId, String testExecutionId, String jiraUsername, String jiraApiToken) throws IOException {
        String activeSprintId = getActiveSprintId(boardId, jiraUsername, jiraApiToken);
        JSONObject jsonObject = new JSONObject()
                .put("issues", Lists.newArrayList(testExecutionId));
        RequestBody requestBody = RequestBody.create(jsonObject.toString(), JSON);
        String credential = Credentials.basic(jiraUsername, jiraApiToken);
        Request request = new Request.Builder()
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", credential)
                .post(requestBody)
                .url(JIRA_BASE_URL + "/rest/agile/1.0/sprint/" + activeSprintId + "/issue")
                .build();
        OkHttpClient client = new OkHttpClient();
        Response response = client.newCall(request).execute();
        assert response.code() == 204;
    }
}
