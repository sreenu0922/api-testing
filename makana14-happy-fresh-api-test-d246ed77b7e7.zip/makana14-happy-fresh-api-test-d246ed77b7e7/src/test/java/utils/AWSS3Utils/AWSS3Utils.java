package utils.AWSS3Utils;

import api.DataGenerator;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.transfer.*;
import org.apache.kafka.common.protocol.types.Field;

import java.io.File;

/**
 * Utility class for AWS S3 with AWS Java SDK
 */
public class AWSS3Utils {
    private final static String BUCKET_NAME = "automation-result.happyfresh.net";
    private final static String REPORT_DIRECTORY = DataGenerator.rootDir() + "/target/cucumber-html-reports";

    /**
     * Upload directory to S3 bucket
     * @param key_prefix path folder on S3 bucket
     * @param dir_path path of directory to be uploaded
     * @param bucket_name S3 bucket name
     * @param recursive True if want to upload directory inside main directory, False otherwise
     * @param pause pause upload
     */
    public static void uploadDir(String key_prefix, String dir_path, String bucket_name,
                                 boolean recursive, boolean pause) {
        System.out.println("directory: " + dir_path + (recursive ?
                " (recursive)" : "") + (pause ? " (pause)" : ""));

        // snippet-start:[s3.java1.s3_xfer_mgr_upload.directory]
        TransferManager xfer_mgr = TransferManagerBuilder.standard().build();
        try {
            MultipleFileUpload xfer = xfer_mgr.uploadDirectory(bucket_name,
                    key_prefix, new File(dir_path), recursive);
            // loop with Transfer.isDone()
            XferMgrProgress.showTransferProgress(xfer);
            // or block with Transfer.waitForCompletion()
            XferMgrProgress.waitForCompletion(xfer);
        } catch (AmazonServiceException e) {
            System.err.println(e.getErrorMessage());
            System.exit(1);
        }
        xfer_mgr.shutdownNow();
        // snippet-end:[s3.java1.s3_xfer_mgr_upload.directory]
    }

    /**
     * Send cucumber html report to AWS S3 bucket automation-result.happyfresh.net
     */
    public static void sendReportToS3(){
        try{
            if(System.getenv("BITBUCKET_REPO_SLUG") != null | System.getenv("BITBUCKET_BUILD_NUMBER") != null){
                System.out.println("Sending cucumber html report to S3");
                String key_prefix = "api/" + System.getenv("BITBUCKET_REPO_SLUG") + "/" + System.getenv("BITBUCKET_BUILD_NUMBER");
                uploadDir(key_prefix, REPORT_DIRECTORY, BUCKET_NAME, true, false);
                System.out.println("Report url: https://s3.ap-southeast-1.amazonaws.com/automation-result.happyfresh.net/" + key_prefix + "/overview-features.html");
            }
            System.out.println("BITBUCKET_REPO_SLUG and BITBUCKET_BUILD_NUMBER envar is null. This session doesn't send report to S3");
        } catch (Exception e){
            e.printStackTrace();
        }

    }

}
